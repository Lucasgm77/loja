require 'test_helper'

class ProdutosHelperTest < ActionView::TestCase
end
