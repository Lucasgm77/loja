class CreateProdutos < ActiveRecord::Migration
  def change
    create_table :produtos do |t|
      t.string :nome
      t.text :descricao
      t.decimal :preco
      t.decimal :peso
      t.decimal :valor_de_entrega
      t.integer :qtd_em_estoque
      t.integer :qtd_vendida

      t.timestamps
    end
  end
end
