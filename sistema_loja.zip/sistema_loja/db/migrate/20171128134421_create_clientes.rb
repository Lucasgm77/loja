class CreateClientes < ActiveRecord::Migration
  def change
    create_table :clientes do |t|
      t.string :nome
      t.string :sobrenome
      t.string :endereco
      t.string :telefone
      t.date :data_nascimento
      t.integer :qtd_prod_comprados
      t.decimal :valor_comprado

      t.timestamps
    end
  end
end
