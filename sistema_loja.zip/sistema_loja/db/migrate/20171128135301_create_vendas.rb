class CreateVendas < ActiveRecord::Migration
  def change
    create_table :vendas do |t|
      t.references :produtos, index: true
      t.references :cliente, index: true
      t.decimal :valor
      t.boolean :entrega_solicitada
      t.string :forma_pagamento
      t.boolean :garantia_estendida
      t.decimal :valor_total

      t.timestamps
    end
  end
end
