class Clientes < ActiveRecord::Base
	has_many :vendas
end
