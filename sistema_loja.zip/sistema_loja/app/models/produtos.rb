class Produtos < ActiveRecord::Base
end
