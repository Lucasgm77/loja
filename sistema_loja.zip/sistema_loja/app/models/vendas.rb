class Vendas < ActiveRecord::Base
  has_many :produtos
  belongs_to :cliente
end
